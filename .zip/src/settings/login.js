const login = {
    fields: [
        {id: 1,
        label: 'Username',
        name: 'Username',
        type: 'text',
        placeholder: 'Enter Username',
        },
        {id: 2,
            label: 'Password',
            name: 'Password',
            type: 'Password',
            placeholder: 'Enter Password',
            }

    ]
}

module.exports = login;