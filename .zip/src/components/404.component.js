import React, { Component } from 'react';

class notFound extends Component {
  constructor(props) {
    super(props);
    this.state = {brand: "Ford"};
  }
  componentDidMount() {
    this.setState({comment: 'Hello'});
  }


  render() {
    return (
    <div className="container"> <h1 className="pt-3">404 Not Found</h1></div>
    );
  }
}

export default notFound