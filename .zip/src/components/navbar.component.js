import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import navbarSettings from "../settings/navbar";
import  { Auth }   from 'aws-amplify';

export default class Navbar extends Component {
  constructor(props) {
    super(props);
    this.state = {
      toggle:false
    }
    console.log('Navbar constructor // State after assignment : ' )
    this.handleToggle = this.handleToggle.bind(this);
    this.navbar = []
    this.buttons = []
    console.log(navbarSettings.buttons_auth)
  }
  handleToggle() {
    this.setState(state => ({
      toggle: !state.toggle
    }));
  }
  componentDidMount() {
  }

    handleLogOut = async event => {
      alert('logginout')
      event.preventDefault();
      try {
        Auth.signOut();
      this.props.data.setSomeState({
        user: null,
        isAuthenticated:false
      })
      window.location.href = "/"
      }catch(error) {
        console.log('error')
        console.log(error.message);
      }
    }
  render() {
    if(this.props.data.isAuthenticated){
      this.navbar = navbarSettings.items_auth
      this.buttons = navbarSettings.buttons_auth  
    } else{
      this.navbar = navbarSettings.items_unauth
      this.buttons = navbarSettings.buttons_unauth  
    }
    return (
      <div className='container'>
        {/* <div className='support row container '>
          <div className='col d-inline text-light px-5 my-auto'>         
           <img src="http://icons.iconarchive.com/icons/uiconstock/folded-social-media/48/Email-icon.png"/>
          <h6 className='d-inline pl-2 '> Support@investfolio.ai</h6>
</div>

          <div className='col '>
            <div className='float-right py-3'>
            <div className="btn-group btn-group-toggle" data-toggle="buttons">
              <label className="btn btn-secondary bg-dark ">
              <input type="radio" name="options" id="option1" autocomplete="off" checked/> <Link to={navbarSettings.login[0].url} className="">{navbarSettings.login[0].name}</Link>
            </label>
            <label className="btn btn-secondary">
            <input type="radio" name="options" id="option1" autocomplete="off" checked/> <Link to={navbarSettings.login[1].url} className="">{navbarSettings.login[1].name}</Link>
            </label>
          </div>      
            </div>
          </div>

        </div> */}
        <nav className="pt-4 navbar navbar-dark  navbar-expand-lg">
          <Link to="/" className="navbar-brand">{navbarSettings.brand_name}  </Link>
          <button className="navbar-toggler" type="button" onClick={this.handleToggle}>
            <span className="navbar-toggler-icon"></span>
          </button>

          <div className="collpase navbar-collapse " id="collapse" style={this.state.toggle ? { display: 'block' } : { display: 'none' }}>

            <ul className="navbar-nav pl-4 mr-auto">
              {this.navbar.map(item =>
                <li key={item.id} className={"navbar-item px-3"} >
                  <Link 
                  to={{
                    pathname:item.url,
                    }} 
                  className="nav-link">{item.name}</Link>
                </li>
              )}
            </ul>
            
            {this.buttons.map(item =>
              
              <Link 
              key={item.id} 

              to={{
                pathname:item.url,
                }} 
              onClick = {eval(item.onclick)}
              className="p-2">
                <button name="options" id="option1" className='btn btn-outline-secondary  p-1 ' > <p className='m-0 p-1 px-3'>{item.name}</p></button>
              </Link>
            
            )}
          </div>
        </nav></div>
    );
  }
}
