import React, { Component } from 'react';

class Index extends Component {
  constructor(props) {
    super(props);
    console.log('Index constructor // State after assignment : ' )
  }
  componentDidMount(){

  }

  render() {
    console.log(this.props.data)
    if(this.props.data.isAuthenticated){
      console.log(this.state)
      return (
        <div className = "main">
          
        <p className="text-light h-5"> Signed In </p>
        {/* <p className="text-light h-5"> Username : {this.state.user.payload['cognito:username']} </p> */}

        </div>
        );
    } else {
    return (
      <div className = "main">
        
      <p className="text-light"> not signed in </p>
  
      </div>
      );}
      
  }
}

export default Index