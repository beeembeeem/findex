import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import navbarSettings from "../settings/navbar";
import  Auth  from 'aws-amplify';

export default class signout extends Component {
    constructor(props){
        super(props);
        this.state = {
          signiningout: false
        }
        this.signout = this.signout.bind(this)
    }
    signout(){
      var that = this;
      alert('signout')
      Auth.signOut()
      .then(data => {
        alert(data)
        that.setState({ signedout:true})

      })
      .catch(err => console.log(err));
    }
      //before each render, check the prop for user data and add it to state
  static getDerivedStateFromProps(props, state){
    if (props.data.signed){
        Auth.signOut();
        this.props.data.signed = false;
    }
    return state
    }
  render() {
    console.log(this.state)
      if (!this.state.signiningout){
        return (
          <p>Loading ...</p>
            );
      } else if (this.state.signiningout){
        return (window.location.href = "/signin")
      }
  }
}